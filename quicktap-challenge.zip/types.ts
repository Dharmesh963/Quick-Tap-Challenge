
export enum GameState {
  NotStarted,
  Playing,
  GameOver,
}

export interface TargetPosition {
  row: number;
  col: number;
}

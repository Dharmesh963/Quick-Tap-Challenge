
export const GAME_DURATION_SECONDS = 30;
export const GRID_SIZE = 4;
export const TARGET_APPEAR_INTERVAL_MS = 800;


import React from 'react';
import { TargetPosition } from '../types';
import { GRID_SIZE } from '../constants';

interface GameGridProps {
  targetPosition: TargetPosition | null;
  onTargetClick: () => void;
}

const GameGrid: React.FC<GameGridProps> = ({ targetPosition, onTargetClick }) => {
  const gridCells = Array.from({ length: GRID_SIZE * GRID_SIZE });

  return (
    <div
      className="grid h-full w-full select-none bg-slate-900/70 p-2"
      style={{ gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)` }}
    >
      {gridCells.map((_, index) => {
        const row = Math.floor(index / GRID_SIZE);
        const col = index % GRID_SIZE;
        const isTarget = targetPosition?.row === row && targetPosition?.col === col;

        return (
          <div
            key={index}
            className="w-full h-full flex items-center justify-center p-2"
          >
            {isTarget && (
              <div
                onClick={onTargetClick}
                className="w-full h-full rounded-full bg-fuchsia-500 cursor-pointer transition-transform duration-100 ease-in-out hover:scale-110 active:scale-95 animate-pulse-glow"
                style={{
                  boxShadow: '0 0 10px #f0f, 0 0 20px #f0f, 0 0 30px #f0f',
                  animation: 'pulse-glow 1.5s infinite ease-in-out'
                }}
              >
                <style>
                  {`
                    @keyframes pulse-glow {
                      0%, 100% {
                        transform: scale(0.95);
                        box-shadow: 0 0 10px #d946ef, 0 0 20px #d946ef, 0 0 30px #d946ef;
                      }
                      50% {
                        transform: scale(1.05);
                        box-shadow: 0 0 20px #a21caf, 0 0 30px #a21caf, 0 0 40px #a21caf;
                      }
                    }
                  `}
                </style>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default GameGrid;

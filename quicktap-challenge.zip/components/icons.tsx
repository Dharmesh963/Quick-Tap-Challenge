
import React from 'react';

export const PlayIcon: React.FC = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="transition-transform duration-300 group-hover:translate-x-1"
  >
    <polygon points="5 3 19 12 5 21 5 3"></polygon>
  </svg>
);

export const RestartIcon: React.FC = () => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className="transition-transform duration-500 group-hover:rotate-180"
    >
        <path d="M21.5 2v6h-6"></path>
        <path d="M2.5 22v-6h6"></path>
        <path d="M4.93 11.93a9 9 0 0 1 14.14 0"></path>
        <path d="M4.93 4.93a9 9 0 0 1 0 14.14"></path>
    </svg>
);

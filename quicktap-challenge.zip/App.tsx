
import React, { useState, useEffect, useCallback } from 'react';
import { GameState, TargetPosition } from './types';
import { GAME_DURATION_SECONDS, GRID_SIZE, TARGET_APPEAR_INTERVAL_MS } from './constants';
import GameGrid from './components/GameGrid';
import { PlayIcon, RestartIcon } from './components/icons';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.NotStarted);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(GAME_DURATION_SECONDS);
  const [targetPosition, setTargetPosition] = useState<TargetPosition | null>(null);
  const [highScore, setHighScore] = useState(() => {
    return parseInt(localStorage.getItem('quickTapHighScore') || '0', 10);
  });

  const updateHighScore = useCallback((currentScore: number) => {
    if (currentScore > highScore) {
      setHighScore(currentScore);
      localStorage.setItem('quickTapHighScore', currentScore.toString());
    }
  }, [highScore]);

  useEffect(() => {
    if (gameState !== GameState.Playing) return;

    if (timeLeft <= 0) {
      setGameState(GameState.GameOver);
      updateHighScore(score);
      setTargetPosition(null);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prevTime) => prevTime - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState, timeLeft, score, updateHighScore]);

  useEffect(() => {
    if (gameState !== GameState.Playing) return;

    const moveTarget = () => {
      const row = Math.floor(Math.random() * GRID_SIZE);
      const col = Math.floor(Math.random() * GRID_SIZE);
      setTargetPosition({ row, col });
    };
    
    moveTarget(); // Initial target
    const targetInterval = setInterval(moveTarget, TARGET_APPEAR_INTERVAL_MS);

    return () => clearInterval(targetInterval);
  }, [gameState]);

  const startGame = () => {
    setScore(0);
    setTimeLeft(GAME_DURATION_SECONDS);
    setGameState(GameState.Playing);
  };

  const handleTargetClick = () => {
    if (gameState === GameState.Playing) {
      setScore((prevScore) => prevScore + 1);
      // Immediately move target for better responsiveness
      const row = Math.floor(Math.random() * GRID_SIZE);
      const col = Math.floor(Math.random() * GRID_SIZE);
      setTargetPosition({ row, col });
    }
  };

  const renderContent = () => {
    switch (gameState) {
      case GameState.NotStarted:
        return <StartScreen onStart={startGame} highScore={highScore} />;
      case GameState.GameOver:
        return <GameOverScreen score={score} highScore={highScore} onRestart={startGame} />;
      case GameState.Playing:
        return <GameGrid targetPosition={targetPosition} onTargetClick={handleTargetClick} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-900 to-indigo-900">
      <div className="w-full max-w-md mx-auto bg-slate-800/50 rounded-2xl shadow-2xl backdrop-blur-sm p-6 border border-slate-700">
        <header className="flex justify-between items-center mb-6 text-slate-300">
          <h1 className="text-2xl font-bold text-white tracking-wider">QuickTap</h1>
          <div className="flex space-x-6 text-center">
            <div>
              <span className="text-xs uppercase tracking-widest text-cyan-400">Time</span>
              <p className="text-2xl font-semibold text-white">{timeLeft}</p>
            </div>
            <div>
              <span className="text-xs uppercase tracking-widest text-fuchsia-400">Score</span>
              <p className="text-2xl font-semibold text-white">{score}</p>
            </div>
          </div>
        </header>
        <main className="aspect-square rounded-lg overflow-hidden">
          {renderContent()}
        </main>
      </div>
       <footer className="text-center mt-6 text-slate-500 text-sm">
        <p>Built with React, TypeScript, and Tailwind CSS.</p>
      </footer>
    </div>
  );
};

interface ScreenProps {
  onStart?: () => void;
  onRestart?: () => void;
  score?: number;
  highScore: number;
}

const StartScreen: React.FC<ScreenProps> = ({ onStart, highScore }) => (
  <div className="w-full h-full bg-slate-900/70 flex flex-col items-center justify-center p-8 text-center">
    <h2 className="text-4xl font-bold text-white mb-2">QuickTap Challenge</h2>
    <p className="text-slate-400 mb-6">Tap the glowing orb before time runs out!</p>
    <p className="text-lg text-slate-300 mb-8">High Score: <span className="font-bold text-cyan-400">{highScore}</span></p>
    <button onClick={onStart} className="group flex items-center justify-center gap-3 bg-cyan-500 hover:bg-cyan-400 text-slate-900 font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg shadow-cyan-500/30">
      <PlayIcon />
      Start Game
    </button>
  </div>
);

const GameOverScreen: React.FC<ScreenProps> = ({ score, highScore, onRestart }) => (
  <div className="w-full h-full bg-slate-900/70 flex flex-col items-center justify-center p-8 text-center">
    <h2 className="text-4xl font-bold text-white mb-2">Game Over</h2>
    <p className="text-xl text-slate-300 mb-4">Your Score: <span className="font-bold text-fuchsia-400">{score}</span></p>
    <p className="text-lg text-slate-400 mb-8">High Score: <span className="font-bold text-cyan-400">{highScore}</span></p>
    <button onClick={onRestart} className="group flex items-center justify-center gap-3 bg-fuchsia-500 hover:bg-fuchsia-400 text-slate-900 font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg shadow-fuchsia-500/30">
      <RestartIcon />
      Play Again
    </button>
  </div>
);

export default App;
